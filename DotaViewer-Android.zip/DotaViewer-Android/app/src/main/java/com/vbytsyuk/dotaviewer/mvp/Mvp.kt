package com.vbytsyuk.dotaviewer.mvp

import android.arch.lifecycle.ViewModel

// Immutable
interface MvpViewState

interface MvpView<in S : MvpViewState> {
    fun render(state: S)
}

abstract class MvpPresenter<S : MvpViewState, V : MvpView<S>>(open var state: S) : ViewModel() {
    private var viewsList: MutableList<V> = ArrayList()

    fun takeView(view: V) {
        viewsList.add(view)
        view.render(state)
    }

    fun takeViews(views: List<V>) = views.forEach(this::takeView)

    fun dropView(view: V) = viewsList.apply {
        if (contains(view)) remove(view)
    }

    fun dropViews() = viewsList.clear()
}
