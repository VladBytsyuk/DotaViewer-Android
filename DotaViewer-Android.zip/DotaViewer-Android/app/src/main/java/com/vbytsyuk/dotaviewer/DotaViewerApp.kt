package com.vbytsyuk.dotaviewer

import android.app.Application
import org.koin.android.ext.android.startKoin
import org.koin.dsl.module.Module
import org.koin.dsl.module.module

object DotaViewerApp : Application() {
    private val appModule: Module by lazy {
        module {
        }
    }

    override fun onCreate() {
        super.onCreate()
        startKoin(this, listOf(appModule))
    }

}