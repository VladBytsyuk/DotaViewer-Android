package com.vbytsyuk.dotaviewer

import android.support.v4.app.Fragment
import com.vbytsyuk.dotaviewer.mvp.MvpPresenter
import com.vbytsyuk.dotaviewer.mvp.MvpView
import com.vbytsyuk.dotaviewer.mvp.MvpViewState
import com.vbytsyuk.dotaviewer.widgets.StatsView

enum class StateEnum { Loading, Data, Error }

val EMPTY_DATA_ERROR = R.string.error_text_empty_data.resString

data class ProfileViewState(
    val state: StateEnum = StateEnum.Loading,
    val header: StatsView.Data? = null,
    val error: String? = null
) : MvpViewState

class ProfileFragment : Fragment(), MvpView<ProfileViewState> {
    override fun render(state: ProfileViewState) {
        when (state.state) {
            StateEnum.Loading -> renderLoading()
            StateEnum.Error -> state.error?.let { renderError(it) }
            StateEnum.Data ->
                if (state.header == null) renderError(EMPTY_DATA_ERROR) else renderData(state.header)
        }
    }

    private fun renderLoading() {

    }

    private fun renderData(header: StatsView.Data) {

    }

    private fun renderError(error: String) {

    }
}

class ProfilePresenter : MvpPresenter<ProfileViewState, ProfileFragment>(ProfileViewState())