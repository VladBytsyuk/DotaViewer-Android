package com.vbytsyuk.dotaviewer.mvp

import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.View
import com.vbytsyuk.dotaviewer.R
import com.vbytsyuk.dotaviewer.resString
import org.koin.android.ext.android.inject


enum class BaseMvpStateEnum { Loading, Data, Error }
typealias State = BaseMvpStateEnum

val EMPTY_DATA_ERROR = R.string.error_text_empty_data.resString


open class BaseMvpViewState(
    val state: State = State.Loading,
    val error: String? = null
) : MvpViewState


abstract class BaseMvpFragment<P : BaseMvpPresenter, VS : BaseMvpViewState> :
    Fragment(), MvpView<VS> {
//    var presenter: P by inject()

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
//        presenter.takeView(this)
    }

    override fun onDestroyView() {
        super.onDestroyView()
//        presenter.dropView(this)
    }
}


abstract class BaseMvpPresenter(
    override var state: BaseMvpViewState
) //: MvpPresenter<BaseMvpViewState, BaseMvpFragment<*, *>>(state)